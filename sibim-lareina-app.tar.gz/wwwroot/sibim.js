// Utilidades de SIBIM usadas desde Blazor.
window.sibim = {
  // Descarga un archivo generado en el servidor (bytes en base64).
  descargar: function (nombre, tipo, base64) {
    const bytes = Uint8Array.from(atob(base64), c => c.charCodeAt(0));
    const url = URL.createObjectURL(new Blob([bytes], { type: tipo }));
    const a = document.createElement('a');
    a.href = url; a.download = nombre; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  },
  imprimir: function () { window.print(); },
  abrir: function (url) { window.open(url, '_blank'); }
};

// Dibuja códigos QR en los elementos con atributo data-qr (etiquetas de inventario).
window.sibim.dibujarQr = function () {
  if (typeof qrcode !== 'function') return;
  document.querySelectorAll('[data-qr]:not([data-qr-listo])').forEach(function (el) {
    const texto = el.getAttribute('data-qr');
    const qr = qrcode(0, 'M');
    // Modo alfanumérico (solo mayúsculas, dígitos y $%*+-./: ) = QR más simple; margen blanco de 2 módulos.
    qr.addData(texto, /^[0-9A-Z $%*+\-./:]*$/.test(texto) ? 'Alphanumeric' : 'Byte');
    qr.make();
    el.innerHTML = qr.createSvgTag({ cellSize: 4, margin: 8, scalable: true });
    el.setAttribute('data-qr-listo', '1');
  });
};
document.addEventListener('DOMContentLoaded', window.sibim.dibujarQr);
if (window.Blazor && Blazor.addEventListener) Blazor.addEventListener('enhancedload', window.sibim.dibujarQr);

// Menú lateral colapsable: botón ☰ o tecla F11 (como en el sistema anterior). Se recuerda en este navegador.
window.sibimMenu = function (forzar) {
  if (window.innerWidth <= 900) { document.body.classList.toggle('menu-visible', forzar); return; }
  const oculto = document.body.classList.toggle('menu-oculto', forzar);
  try { localStorage.setItem('sibim-menu-oculto', oculto ? '1' : '0'); } catch (e) { }
};
(function () {
  let guardado = null;
  try { guardado = localStorage.getItem('sibim-menu-oculto'); } catch (e) { }
  const aplicar = function () { if (guardado === '1') document.body.classList.add('menu-oculto'); };
  if (document.body) aplicar(); else document.addEventListener('DOMContentLoaded', aplicar);
  document.addEventListener('keydown', function (e) {
    if (e.key === 'F11') { e.preventDefault(); window.sibimMenu(); }
  });
})();
