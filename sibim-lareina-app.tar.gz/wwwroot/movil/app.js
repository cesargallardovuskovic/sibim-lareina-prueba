// SIBIM · App móvil de toma de inventario.
// Lee etiquetas QR, valida contra los bienes esperados y envía las lecturas al servidor.
// Sin conexión, las lecturas quedan en una cola local (localStorage) y se envían al volver la señal.
(function () {
  'use strict';
  const BASE = new URL('..', location.href).pathname;          // raíz de la aplicación (soporta sitios en subcarpeta)
  const API = BASE + 'api/tomas';
  const $ = id => document.getElementById(id);
  let toma = null;          // datos de la toma (esperados + lecturas)
  let lector = null;        // instancia Html5Qrcode
  let ultimoCodigo = '', ultimoMomento = 0, ultimoNoRegistrado = null;

  // ---------- almacenamiento local ----------
  const guardar = (k, v) => { try { localStorage.setItem('sibim.' + k, JSON.stringify(v)); } catch (e) { } };
  const leer = (k, def) => { try { const v = localStorage.getItem('sibim.' + k); return v ? JSON.parse(v) : def; } catch (e) { return def; } };
  const cola = () => leer('cola.' + toma.id, []);
  const ponerCola = c => { guardar('cola.' + toma.id, c); pintarCola(); };

  // ---------- servidor ----------
  async function api(ruta, opciones) {
    const r = await fetch(API + ruta, Object.assign({ credentials: 'same-origin', headers: { 'X-SIBIM': '1', 'Content-Type': 'application/json' } }, opciones || {}));
    if (r.status === 401) { location.href = BASE + 'ingresar?returnUrl=' + encodeURIComponent(location.pathname); throw new Error('sesión'); }
    if (r.status === 403) throw new Error('Su usuario no tiene permiso para tomas de inventario.');
    const datos = r.headers.get('content-type')?.includes('json') ? await r.json() : null;
    if (!r.ok) throw new Error((datos && datos.error) || ('Error ' + r.status));
    return datos;
  }

  function estadoRed() { $('red').classList.toggle('off', !navigator.onLine); $('red').title = navigator.onLine ? 'Con conexión' : 'Sin conexión'; }
  window.addEventListener('online', () => { estadoRed(); sincronizar(); });
  window.addEventListener('offline', estadoRed);

  // ---------- normalización y dígito verificador (módulo 11) ----------
  // Acepta el enlace de la etiqueta (https://…/B/0402-000123-4), el formato antiguo "SIBIM:…" o el código digitado.
  function normalizar(t) {
    t = (t || '').trim().toUpperCase();
    const m = t.match(/\/B\/([^/?#]+)\/?$/);
    if (m) { try { t = decodeURIComponent(m[1]); } catch { t = m[1]; } }
    return t.startsWith('SIBIM:') ? t.substring(6) : t;
  }
  function dv(num) { let s = 0, f = 2; for (let i = num.length - 1; i >= 0; i--) { s += (+num[i]) * f; f = f === 7 ? 2 : f + 1; } const r = 11 - (s % 11); return r === 11 ? '0' : r === 10 ? 'K' : String(r); }
  function codigoValido(c) { const p = c.split('-'); return p.length === 3 && /^\d{4}$/.test(p[0]) && /^\d{6}$/.test(p[1]) && dv(p[0] + p[1]) === p[2]; }

  // ---------- vistas ----------
  function vista(id) {
    ['v-tomas', 'v-leer', 'v-pend', 'v-res'].forEach(v => $(v).classList.toggle('oculto', v !== id));
    document.querySelectorAll('#tabs button').forEach(b => b.classList.toggle('on', b.dataset.v === id));
    if (id === 'v-pend') pintarPendientes();
    if (id === 'v-res') pintarResumen();
  }
  document.querySelectorAll('#tabs button').forEach(b => b.addEventListener('click', () => vista(b.dataset.v)));

  async function cargarTomas() {
    try {
      const tomas = await api('/');
      guardar('tomas', tomas);
      pintarTomas(tomas);
    } catch (e) {
      if (e.message === 'sesión') return;
      const t = leer('tomas', []);
      pintarTomas(t, 'Sin conexión: se muestran las tomas guardadas en el teléfono.');
    }
  }

  function pintarTomas(tomas, aviso) {
    const el = $('tomas');
    el.innerHTML = (aviso ? `<div class="alert a-warn">${aviso}</div>` : '') +
      (tomas.length === 0 ? '<div class="cargando">No hay tomas abiertas.</div>' :
        tomas.map(t => `<div class="item click" data-id="${t.id}"><b>${esc(t.codigo)} · ${esc(t.ubicacion)}</b><span class="hint">${t.fecha} · ${t.estado === 'EN_CURSO' ? 'En curso' : 'Programada'}</span></div>`).join(''));
    el.querySelectorAll('.item').forEach(i => i.addEventListener('click', () => abrirToma(+i.dataset.id)));
  }

  async function abrirToma(id) {
    try { toma = await api('/' + id); guardar('toma.' + id, toma); }
    catch (e) { if (e.message === 'sesión') return; toma = leer('toma.' + id, null); if (!toma) { alert('Sin conexión y sin datos guardados de esta toma.'); return; } }
    guardar('tomaActual', id);
    $('cab-toma').textContent = 'Toma de inventario · ' + toma.codigo;
    $('cab-titulo').textContent = toma.ubicacion;
    $('progreso').classList.remove('oculto');
    $('tabs').classList.remove('oculto');
    pintarProgreso(); pintarCola();
    vista('v-leer');
    sincronizar();
  }

  // ---------- lectura ----------
  function registrar(texto) {
    const codigo = normalizar(texto);
    if (!codigo) return;
    const ahora = Date.now();
    if (codigo === ultimoCodigo && ahora - ultimoMomento < 3000) return;   // evita lecturas repetidas de la misma etiqueta
    ultimoCodigo = codigo; ultimoMomento = ahora;
    if (navigator.vibrate) navigator.vibrate(60);

    const esperado = toma.esperados.find(e => e.codigo === codigo);
    const estado = $('estado').value ? +$('estado').value : null;
    let resultado, detalle;
    if (esperado) { esperado.leido = true; resultado = 'ENCONTRADO'; detalle = `${esc(esperado.descripcion)}<br><span class="hint">${esc(esperado.ubicacion)} · ${esc(esperado.responsable || 'sin responsable')}</span>`; }
    else if (!codigoValido(codigo) && !/^[0-9][0-9-]{5,17}[0-9K]$/.test(codigo)) { resultado = 'INVALIDO'; detalle = 'El código no tiene un formato válido. Revise la etiqueta.'; }
    else { resultado = 'POR_VERIFICAR'; detalle = 'No está registrado en esta ubicación. Se verificará con el servidor.'; }

    if (resultado !== 'INVALIDO') {
      const c = cola(); c.push({ Codigo: codigo, EstadoConservacionId: estado, LeidoEn: new Date().toISOString(), Dispositivo: navigator.userAgent.substring(0, 100) }); ponerCola(c);
      guardar('toma.' + toma.id, toma);
    }
    mostrarUltimo(codigo, resultado, detalle);
    pintarProgreso();
    sincronizar();
  }

  function mostrarUltimo(codigo, resultado, detalle) {
    const etiquetas = { ENCONTRADO: ['t-ok', '✓ Encontrado'], MAL_UBICADO: ['t-warn', 'Mal ubicado'], NO_REGISTRADO: ['t-bad', 'No registrado'], POR_VERIFICAR: ['t-info', 'Por verificar'], INVALIDO: ['t-bad', 'Código no válido'] };
    const [clase, texto] = etiquetas[resultado] || ['t-grey', resultado];
    $('ultimo').classList.remove('oculto');
    $('ultimo').innerHTML = `<div class="res"><span class="tag ${clase}">${texto}</span> <span class="mono">${esc(codigo)}</span></div><div>${detalle}</div>`;
    $('noreg').classList.toggle('oculto', resultado !== 'NO_REGISTRADO');
    ultimoNoRegistrado = resultado === 'NO_REGISTRADO' ? codigo : null;
  }

  $('f-manual').addEventListener('submit', e => { e.preventDefault(); registrar($('manual').value); $('manual').value = ''; });
  $('noreg-ok').addEventListener('click', () => {
    if (!ultimoNoRegistrado) return;
    const c = cola(); c.push({ Codigo: ultimoNoRegistrado, Descripcion: $('noreg-desc').value, LeidoEn: new Date().toISOString() }); ponerCola(c);
    $('noreg-desc').value = ''; $('noreg').classList.add('oculto'); sincronizar();
  });

  $('b-camara').addEventListener('click', async () => {
    if (lector) { await lector.stop().catch(() => { }); lector = null; $('lector').innerHTML = ''; $('b-camara').textContent = '📷 Activar cámara'; return; }
    if (typeof Html5Qrcode === 'undefined') { alert('No se pudo cargar el lector de códigos.'); return; }
    lector = new Html5Qrcode('lector', { formatsToSupport: [Html5QrcodeSupportedFormats.QR_CODE], experimentalFeatures: { useBarCodeDetectorIfSupported: true }, verbose: false });
    try {
      // Se analiza la imagen completa (antes solo un recuadro de 220 px: si la etiqueta quedaba más grande o corrida, no se leía).
      await lector.start({ facingMode: 'environment' }, { fps: 12 }, texto => registrar(texto));
      $('b-camara').textContent = '■ Detener cámara';
    } catch (e) {
      lector = null;
      alert('No se pudo usar la cámara. Revise el permiso del navegador (la página debe abrirse con https). También puede digitar el código.');
    }
  });

  // ---------- sincronización ----------
  let sincronizando = false;
  async function sincronizar() {
    if (!toma || sincronizando || !navigator.onLine) return;
    const pendientes = cola();
    if (pendientes.length === 0) return;
    sincronizando = true;
    try {
      const resultados = await api('/' + toma.id + '/lecturas', { method: 'POST', body: JSON.stringify(pendientes) });
      ponerCola(cola().slice(pendientes.length));
      resultados.forEach(r => {
        const i = toma.lecturas.findIndex(l => l.codigo === r.codigo); if (i >= 0) toma.lecturas[i] = r; else toma.lecturas.push(r);
      });
      guardar('toma.' + toma.id, toma);
      const ultimo = resultados[resultados.length - 1];
      if (ultimo && ultimo.codigo === ultimoCodigo && ultimo.resultado !== 'ENCONTRADO')
        mostrarUltimo(ultimo.codigo, ultimo.resultado, ultimo.resultado === 'MAL_UBICADO'
          ? `${esc(ultimo.descripcion || '')}<br><span class="hint">Registrado en: ${esc(ultimo.ubicacionRegistrada || '?')}</span>` : 'Este código no existe en el sistema.');
    } catch (e) {
      if (e.message !== 'sesión' && navigator.onLine) console.warn('Sincronización:', e.message);
    } finally { sincronizando = false; pintarProgreso(); }
  }
  setInterval(sincronizar, 20000);
  $('b-sync').addEventListener('click', () => sincronizar().then(pintarResumen));

  // ---------- pintado ----------
  function pintarProgreso() {
    if (!toma) return;
    const total = toma.esperados.length, leidos = toma.esperados.filter(e => e.leido).length;
    const p = total ? Math.round(100 * leidos / total) : 0;
    $('prog-n').textContent = `${leidos} de ${total} encontrados`;
    $('prog-p').textContent = p + ' %';
    $('prog-bar').style.width = p + '%';
    $('n-pend').textContent = total - leidos ? `(${total - leidos})` : '';
  }
  function pintarCola() { const n = toma ? cola().length : 0; $('n-cola').textContent = n ? `· ${n} sin enviar` : ''; }
  function pintarPendientes() {
    const p = toma.esperados.filter(e => !e.leido);
    $('pendientes').innerHTML = p.length === 0 ? '<div class="alert a-ok">✓ Todos los bienes esperados fueron leídos.</div>'
      : p.map(e => `<div class="item"><b class="mono">${esc(e.codigo)}</b>${esc(e.descripcion)}<div class="hint">${esc(e.ubicacion)}</div></div>`).join('');
  }
  function pintarResumen() {
    const enc = toma.esperados.filter(e => e.leido).length;
    const mal = toma.lecturas.filter(l => l.resultado === 'MAL_UBICADO').length;
    const nr = toma.lecturas.filter(l => l.resultado === 'NO_REGISTRADO').length;
    const falt = toma.esperados.length - enc;
    $('resumen').innerHTML =
      `<div class="cifra"><span>Encontrados</span><b>${enc}</b></div>` +
      `<div class="cifra ${falt ? 'bad' : ''}"><span>Pendientes (faltantes si se cierra ahora)</span><b>${falt}</b></div>` +
      `<div class="cifra ${mal ? 'warn' : ''}"><span>Mal ubicados</span><b>${mal}</b></div>` +
      `<div class="cifra"><span>Sin etiqueta / no registrados</span><b>${nr}</b></div>` +
      `<div class="cifra"><span>Lecturas sin enviar</span><b>${cola().length}</b></div>`;
  }

  $('b-cerrar').addEventListener('click', async () => {
    if (cola().length > 0) { await sincronizar(); if (cola().length > 0) { alert('Hay lecturas sin enviar. Conéctese a internet antes de cerrar.'); return; } }
    if (!confirm('¿Cerrar la toma? Los bienes no leídos quedarán como faltantes.')) return;
    try { const r = await api('/' + toma.id + '/cerrar', { method: 'POST' }); alert(r.mensaje); localStorage.removeItem('sibim.toma.' + toma.id); location.reload(); }
    catch (e) { if (e.message !== 'sesión') alert(e.message); }
  });
  $('b-otra').addEventListener('click', () => { localStorage.removeItem('sibim.tomaActual'); location.reload(); });

  function esc(s) { return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]); }

  // ---------- inicio ----------
  estadoRed();
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(() => { });
  const actual = leer('tomaActual', null);
  if (actual) abrirToma(actual); else cargarTomas();
})();
